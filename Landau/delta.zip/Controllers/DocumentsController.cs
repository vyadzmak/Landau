﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Landau.DB;
using Landau.Helper;
using Landau.Models.CommentModel;
using Landau.Models.DocumentModel;
using Landau.Models.UserModel;
using PagedList.Mvc;
using PagedList;
namespace Landau.Controllers
{
    public class DocumentsController : Controller
    {



        /// <summary>
        /// Добавление комментария в БД
        /// </summary>
        /// <param name="userModel"></param>
        /// <param name="message"></param>
        /// <returns></returns>

        [HttpPost]
        public JsonResult SendtoEmail(UserModel userModel, string message)
        {
            try
            {
                int sendUserId = (int)Session["UserId"];
                if ((int)Session["Roles"] == 2)
                {
                    bool addcomment = CommentHelper.AddComment(sendUserId, userModel.Id, userModel.DocumentId, message);

                    if (addcomment)
                    {
                        bool checksend = SendEmailHelper.SendToEmail(userModel);
                        if (checksend)
                        {
                            return new JsonResult();
                        }
                        else
                        {
                            return null;
                        }

                    }
                    else
                    {
                        return null;
                    }

                }
                else
                {
                    bool addcomment = CommentHelper.AddComment(sendUserId, 1091, userModel.DocumentId, message);
                    if (addcomment)
                    {
                        bool checksend = SendEmailHelper.SendToEmail(userModel.DocumentId, 1091);
                        if (checksend)
                        {
                            return new JsonResult();
                        }
                        else
                        {
                            return null;
                        }

                    }
                    else
                    {
                        return null;
                    }

                }

            }
            catch (Exception)
            {

                return null;
            }

        }

        #region Uplod Files

        /// <summary>
        /// Загрузка файлов на сервер и добавление их в БД
        /// </summary>
        ///// <param name="files"></param>
        ///// <param name="description"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult Upload(string description)
        {

            try
            {
                // List<int> idList = new List<int>();
                for (int i = 0; i < Request.Files.Count; i++)
                {
                    HttpPostedFileBase file = Request.Files[i]; //Uploaded file
                    var fileextension = Path.GetExtension(file.FileName);
                    Guid name = Guid.NewGuid();
                    var path = Path.Combine(DocumentHelper.ShowSetting(1), name.ToString());
                    var newpath = Path.Combine(path + fileextension);
                    file.SaveAs(newpath);
                    int usersessionid = (int)Session["UserId"];
                    DocumentHelper.AddFile(file, newpath, name, fileextension, usersessionid, description);
                    //  idList.Add( DocumentHelper.AddFile(file, newpath, name, fileextension, usersessionid, description));
                    ViewBag.Roles = Session["Roles"];
                }
                return new JsonResult { Data = null, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            }

            catch (Exception exception)
            {
                return null;
            }

        }



        #endregion
        #region GetInformation from DB
        /// <summary>
        /// Получение информации о файлах с БД
        /// </summary>
        /// <returns></returns>

        public JsonResult GetDocuments(string id)
        {
            try
            {
                int projectId = Int32.Parse(id);
                DocumentsModel models = new DocumentsModel();
                int userId = (int)Session["UserId"];
                if ((int)Session["Roles"] == 1)
                {

                    models.Documents = DocumentHelper.GetToAllFiles(userId, projectId).ToList();
                    ViewBag.Roles = Session["Roles"];

                }
                else
                {

                    models.Documents = DocumentHelper.GetToAllFilesForAnalyst(projectId, userId);

                    ViewBag.Roles = Session["Roles"];


                }
                return new JsonResult { Data = models.Documents, JsonRequestBehavior = JsonRequestBehavior.AllowGet };


            }
            catch (Exception)
            {

                return null;
            }

        }
        public JsonResult GetOrders(string id)
        {
            try
            {
                int projectId = Int32.Parse(id);
                DocumentsModel models = new DocumentsModel();
                LandauEntities entities = new LandauEntities();
                //  var query = (from doc in entities.Documents where doc.ProjectId == projectId && (doc.ViewType == 3) && doc.State != 6 select doc).ToList();
                models.Documents = DocumentHelper.GetToAllOrders(projectId);
                ViewBag.Roles = Session["Roles"];
                return new JsonResult { Data = models.Documents, JsonRequestBehavior = JsonRequestBehavior.AllowGet };





            }
            catch (Exception)
            {

                return null;
            }

        }

        /// <summary>
        /// Получение типов загруженных файлов
        /// </summary>
        /// <returns></returns>
        public JsonResult GetDocumentType()
        {
            try
            {

                List<DocumentTypeListElement> documentTypeList = new List<DocumentTypeListElement>();
                documentTypeList = DocumentHelper.GetToAllTypes().ToList();
                ViewBag.Roles = Session["Roles"];
                return new JsonResult { Data = documentTypeList, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            }
            catch (Exception)
            {

                return null;
            }

        }

        public JsonResult GetMessagesForUser()
        {
            try
            {

                List<CommentModelVm> messages = new List<CommentModelVm>();
                messages = CommentHelper.GetCommentsForUser((int)Session["UserId"]).ToList();
                //     ViewBag.Roles = Session["Roles"];
                return new JsonResult { Data = messages, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            }
            catch (Exception)
            {

                return null;
            }

        }


        #endregion
        #region DownloadFiles
        /// <summary>
        /// Скачивание файлов с БД
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public FileResult Download(int id)
        {
            try
            {
                var file = DocumentHelper.GetFile(id);
                var filename = Path.Combine(DocumentHelper.ShowSetting(1), file.ServerPath);
                if (file.DocumentTypeInt == 3)
                {
                    FileStream fsSource = new FileStream(filename, FileMode.Open, FileAccess.Read);
                    ViewBag.Roles = Session["Roles"];
                    return new FileStreamResult(fsSource, file.DocumentType);
                }
                else if (file.DocumentTypeInt == 4)
                {
                    ViewBag.Roles = Session["Roles"];
                    return base.File(filename, "image/jpeg");
                }
                else
                {
                    ViewBag.Roles = Session["Roles"];
                    return File(filename, file.DocumentType, file.FileName);
                }

            }
            catch (Exception exception)
            {

                return null;
            }
        }
        #endregion
        /// <summary>
        /// Получение комментариев о файлах
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public JsonResult GetComment(int id)
        {
            try
            {
                int userid = (int)Session["UserId"];
                List<CommentModelVm> comments = new List<CommentModelVm>();
                comments = CommentHelper.GetComments(id, userid).ToList();

                return new JsonResult { Data = comments, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            }
            catch (Exception)
            {

                return null; ;
            }
        }
        /// <summary>
        /// Страница чата
        /// </summary>
        /// <param name="documentid"></param>
        /// <returns></returns>
        public ActionResult Chat(int documentid)
        {
            try
            {
                if (Session["UserId"] != null)
                {
                    ViewBag.StartSession = Session["UserId"];
                    ViewBag.StartLogin = Session["Name"];
                    DocumentModelVm document = new DocumentModelVm();
                    document = DocumentHelper.GetFile(documentid);
                    ViewBag.Roles = Session["Roles"];
                    UserModel user = new UserModel();

                    user = UserHelper.GetUser(document.UserInt);
                    user.DocumentId = documentid;
                    return View(user);
                }
                else
                {
                    return RedirectToAction("Login", "Account");
                }
            }
            catch (Exception)
            {

                return null;
            }

        }

        public JsonResult WaitConfirm()
        {
            try
            {
                var model = DocumentHelper.ChangeWaitFiles((int)Session["UserId"]);
                return new JsonResult { Data = model, JsonRequestBehavior = JsonRequestBehavior.AllowGet };
            }
            catch (Exception exception)
            {

                return null;
            }
        }

    }
}