﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Script.Serialization;
using Landau.DB;
using Landau.Helper;
using Landau.Models;
using Landau.Models.MyDocumentModels.EnterpriseSheetModels;
using Landau.Models.XModels;
using Landau.Models.Chart;
using System.Drawing;
using Landau.Helper.Converters;
using Landau.Models.Modal;

namespace Landau.Controllers
{
    public class CabinetController : Controller
    {
        //
        // GET: /Cabinet/

        public static XDocument Document { get; set; }


        public static int Id { get; set; }

        [HttpGet]
        public ActionResult Cabinet(int? id)
        {
            try
            {
                if (Session["UserId"] != null)
                {
                    ViewBag.StartSession = Session["UserId"];
                    ViewBag.StartLogin = Session["Name"];
                    //if (id == null)
                    //{
                    //    Id = DatabaseToModelConverter.GetLastDocumentId();
                    //}
                    //else
                    //{
                    //    Id = id.Value;
                    //}

                    // Метод, достающий документ из базы. Не трогать!!!
                    //Document = DatabaseToModelConverter.GetDocumentFromDatabase(Id);

                    //ExplicitDocumentCreation creator = new ExplicitDocumentCreation();
                    //JavaScriptSerializer serializer = new JavaScriptSerializer();

                    //// Метод, задающий документ явно
                    //// Document = creator.ExcplicitDocumentGet();

                    //ConverterToEnterpriseSheetModel converter = new ConverterToEnterpriseSheetModel();
                    //EnterpriseSheetDocument esDocument = converter.ConvertDocument(Document);

                    //#region correcting the final string

                    //JsonModel jsonModel = new JsonModel();
                    //jsonModel.Value = serializer.Serialize(esDocument);
                    //jsonModel.Value = Extensions.RemoveJsonNulls(jsonModel.Value);
                    //jsonModel.Value = jsonModel.Value.Replace(",}", "}");

                    //#endregion

                    ////  return RedirectToAction("IndexMy");

                    return View(/*jsonModel*/);
                }
                else
                {
                    return RedirectToAction("Login", "Account");
                }
            }
            catch (Exception exception)
            {
                LogHelper.AddLog("Error. Login. Error:" + exception.Message + ". Inner Exception: " + exception.InnerException.Message);
                return null;
            }
        }

        [HttpPost]
        public void Cabinet(string sheetNumberVar, string rowVar, string colVar, string afterChangesVar, string originVar, string current)
        {
            try
            {
                XSheet sheet = new XSheet();
                XBody body = new XBody();
                XCell cell = new XCell();
                XRow row = new XRow();

                List<XRow> rowsNew = new List<XRow>();
                List<XCell> cellsNew = new List<XCell>();

                JavaScriptSerializer deserializer = new JavaScriptSerializer();

                EnterpriseSheetJson deserializedCell = deserializer.Deserialize<EnterpriseSheetJson>(current);

                int indent = 0;

                System.Text.RegularExpressions.Regex reg = new System.Text.RegularExpressions.Regex(@"\d+");
                if (deserializedCell.ti != null)
                {
                    var match = reg.Match(deserializedCell.ti);
                    indent = Int32.Parse(match.Value.ToString());
                }




                sheet = DocumentNavigationHelper.GetSheetByNumber(Document, Int32.Parse(sheetNumberVar));
                NewIdAndNumberGetter getter = new NewIdAndNumberGetter();

                if (sheet == null)
                {
                    //cell = new XCell(getter.GetNewCellId(), getter.GetNewNumber(colVar), afterChangesVar);

                    XComment xComment = new XComment(getter.GetNewCommentId(), deserializedCell.comment);
                    XCalc xCalc = new XCalc(deserializedCell.cal);
                    XFormat xFormat = new XFormat(deserializedCell.fm, deserializedCell.dfm);
                    XStyle xStyle = new XStyle(getter.GetNewStyleId(), deserializedCell.fz, deserializedCell.fw, deserializedCell.width,
                        deserializedCell.height, deserializedCell.fs, deserializedCell.ff, deserializedCell.bgc, deserializedCell.color,
                        indent, deserializedCell.ta,
                        CellPropertiesValidator.DecoreLineValidate(deserializedCell.o, deserializedCell.u, deserializedCell.s));

                    cell = new XCell(getter.GetNewCellId(), getter.GetNewNumber(colVar),
                        deserializedCell.data, xStyle, xComment, xFormat, xCalc);
                    cellsNew.Add(cell);

                    row = new XRow(getter.GetNewRowId(), getter.GetNewNumber(rowVar), cellsNew);
                    rowsNew.Add(row);

                    sheet = new XSheet(getter.GetNewSheetId(), getter.GetNewNumber(sheetNumberVar), new XBody(rowsNew));

                    Document.Sheets.Add(sheet);
                }
                else
                {
                    body = sheet.Body;
                    row = DocumentNavigationHelper.GetRowbyNumber(body, Int32.Parse(rowVar));

                    if (row == null)
                    {
                        XComment xComment = new XComment(getter.GetNewCommentId(), deserializedCell.comment);
                        XCalc xCalc = new XCalc(deserializedCell.cal);
                        XFormat xFormat = new XFormat(deserializedCell.fm, deserializedCell.dfm);
                        XStyle xStyle = new XStyle(getter.GetNewStyleId(), deserializedCell.fz, deserializedCell.fw, deserializedCell.width,
                            deserializedCell.height, deserializedCell.fs, deserializedCell.ff, deserializedCell.bgc, deserializedCell.color,
                            indent, deserializedCell.ta,
                            CellPropertiesValidator.DecoreLineValidate(deserializedCell.o, deserializedCell.u, deserializedCell.s));

                        cell = new XCell(getter.GetNewCellId(), getter.GetNewNumber(colVar),
                            deserializedCell.data, xStyle, xComment, xFormat, xCalc);
                        cellsNew.Add(cell);

                        row = new XRow(getter.GetNewRowId(), getter.GetNewNumber(rowVar), cellsNew);
                        sheet.Body.Rows.Add(row);
                    }
                    else
                    {
                        cell = DocumentNavigationHelper.GetCellByNumber(row, Int32.Parse(colVar));

                        if (cell == null)
                        {


                            XComment xComment = new XComment(getter.GetNewCommentId(), deserializedCell.comment);

                            XCalc xCalc = new XCalc(deserializedCell.cal);
                            XFormat xFormat = new XFormat(deserializedCell.fm, deserializedCell.dfm);
                            XStyle xStyle = new XStyle(getter.GetNewStyleId(), deserializedCell.fz, deserializedCell.fw, deserializedCell.width,
                                deserializedCell.height, deserializedCell.fs, deserializedCell.ff, deserializedCell.bgc, deserializedCell.color,
                               indent, deserializedCell.ta,
                                CellPropertiesValidator.DecoreLineValidate(deserializedCell.o, deserializedCell.u, deserializedCell.s));

                            cell = new XCell(getter.GetNewCellId(), getter.GetNewNumber(colVar),
                                deserializedCell.data, xStyle, xComment, xFormat, xCalc);

                            row.Cells.Add(cell);
                        }
                        else
                        {
                            //XComment xComment = new XComment(getter.GetNewCommentId(), deserializedCell.comment);
                            //XCalc xCalc = new XCalc(deserializedCell.cal);
                            //XFormat xFormat = new XFormat(deserializedCell.fm, deserializedCell.dfm);
                            //XStyle xStyle = new XStyle(getter.GetNewStyleId(), deserializedCell.fz, deserializedCell.fw, deserializedCell.width,
                            //    deserializedCell.height, deserializedCell.fs, deserializedCell.ff, deserializedCell.bgc, deserializedCell.color,
                            //    Int32.Parse((reg.Match(deserializedCell.ti)).ToString()), deserializedCell.ta,
                            //    CellPropertiesValidator.DecoreLineValidate(deserializedCell.o, deserializedCell.u, deserializedCell.s));

                            //cell = new XCell(getter.GetNewCellId(), getter.GetNewNumber(colVar),
                            //    deserializedCell.data, xStyle, xComment, xFormat, xCalc);



                            cell.Comment.Message = deserializedCell.comment;

                            cell.Calculation.IsFormula = deserializedCell.cal;
                            cell.Format.Format = deserializedCell.fm;
                            cell.Format.Template = deserializedCell.dfm;
                            cell.Style.Align = deserializedCell.ta;
                            cell.Style.BackgroundColor = deserializedCell.bgc;
                            cell.Style.DecorLine = CellPropertiesValidator.DecoreLineValidate(deserializedCell.o, deserializedCell.u, deserializedCell.s);
                            cell.Style.FontColor = deserializedCell.color;
                            cell.Style.FontFamily = deserializedCell.ff;
                            cell.Style.FontSize = deserializedCell.fz;
                            cell.Style.FontWeight = deserializedCell.fw;
                            cell.Style.Height = deserializedCell.height;
                            cell.Style.Width = deserializedCell.width;
                            cell.Value = deserializedCell.data;

                            cell.Style.Indent = indent;
                        }
                    }
                    Document.Sheets[Int32.Parse(sheetNumberVar) - 1] = sheet;
                }

                ModelToDatabaseConverter.UpdateDatabase(Document, sheet, body, row, cell);

            }

            catch (Exception exception)
            {
            }
        }

        public ActionResult Tables()
        {
            return View();
        }

        public ActionResult Test()
        {
            return View();
        }

        [HttpGet]
        public string GetListOfDocuments()
        {
            try
            {
                JavaScriptSerializer docListSerializer = new JavaScriptSerializer();
                LandauEntities db = new LandauEntities();
                var query = (from doc in db.Documents where doc.ViewType == 3 select doc).ToList();

                return docListSerializer.Serialize(query);
            }
            catch (Exception exception)
            {
                return null;
            }
        }

        [HttpPost]
        public string GetListOfDocuments(string id)
        {
            try
            {
                int projectId = Int32.Parse(id);
                JavaScriptSerializer docListSerializer = new JavaScriptSerializer();
                LandauEntities db = new LandauEntities();
                var query = (from doc in db.Documents where doc.ProjectId == projectId && doc.ViewType == 3 && doc.State == 5 select doc).ToList();

                return docListSerializer.Serialize(query);
            }
            catch (Exception exception)
            {
                LogHelper.AddLog("Error. GetListOfDocuments. Error:" + exception.Message + " InnerException: " + exception.InnerException.Message);
                return null;
            }
        }

        [HttpGet]
        public string GetOrdersList()
        {
            try
            {
                if ((int)Session["Roles"] == 2)
                {
                    JavaScriptSerializer ordersListSerializer = new JavaScriptSerializer();
                    LandauEntities db = new LandauEntities();
                    var query = (from od in db.Projects
                                 join st in db.ProjectStates on od.State equals st.Id
                                 join cl in db.Clients on od.ClientId equals cl.Id
                                 select new
                                 {
                                     Id = od.Id,
                                     Name = cl.Name,
                                     State = st.Description
                                 }).ToList();
                    return ordersListSerializer.Serialize(query);
                }
                else
                {
                    int userid = (int)Session["UserId"];
                    JavaScriptSerializer ordersListSerializer = new JavaScriptSerializer();
                    LandauEntities db = new LandauEntities();
                    var clientid = (from s in db.Users where s.Id == userid select s).FirstOrDefault();


                    var query = (from od in db.Projects
                                 where od.ClientId == clientid.ClientId
                                 join st in db.ProjectStates on od.State equals st.Id
                                 join cl in db.Clients on od.ClientId equals cl.Id
                                 select new
                                 {
                                     Id = od.Id,
                                     Name = cl.Name,
                                     State = st.Description
                                 }).ToList();
                    return ordersListSerializer.Serialize(query);
                }

            }
            catch (Exception exception)
            {
                return null;
            }
        }

        [HttpPost]
        public string GetDocument(string id)
        {
            try
            {
                Autofitter autofiter = new Autofitter();

                // Метод, достающий документ из базы. Не трогать!!!
                Document = DatabaseToModelConverter.GetDocumentFromDatabase(Int32.Parse(id));

                Document = autofiter.GetAutofitedDocument(Document);



                ExplicitDocumentCreation creator = new ExplicitDocumentCreation();
                JavaScriptSerializer serializer = new JavaScriptSerializer();
                FinalJsonHandler handler = new FinalJsonHandler();
                JsonModel jsonModel = new JsonModel();

                // Метод, задающий документ явно
                // Document = creator.ExcplicitDocumentGet();

                ConverterToEnterpriseSheetModel converter = new ConverterToEnterpriseSheetModel();
                EnterpriseSheetDocument esDocument = converter.ConvertDocument(Document);

                jsonModel.Value = handler.ClearJson(serializer.Serialize(esDocument));

               return jsonModel.Value;

            }
            catch (Exception exception)
            {
                LogHelper.AddLog("Error. GetDocument. Error:" + exception.Message + " InnerException: " + exception.InnerException.Message);

                return null;
            }
        }

        [HttpPost]
        public string GetChart(string documentId, string rowNumber, string columnNumber, string sheetNumber)
        {
            try
            {
                string chartInfo = "";
                int cellId = 0;
                int docId = Int32.Parse(documentId);
                int rowNum = Int32.Parse(rowNumber);
                int colNum = Int32.Parse(columnNumber);
                int sheetNum = Int32.Parse(sheetNumber);
                ChartToJsonModelConverter converter = new ChartToJsonModelConverter();

                var db = new LandauEntities();

                #region getting necessary cell id
                
                Sheet validSheet = (from sh in db.Sheet where sh.DocumentId == docId && sh.Number == sheetNum select sh).ToList().LastOrDefault();
                int valSheetId = validSheet.Id;

                Body validBody = (from b in db.Body where b.SheetId == valSheetId select b).ToList().LastOrDefault();
                int valBodyId = validBody.Id;

                Row validRow = (from r in db.Row where r.Number == rowNum && r.BodyId == valBodyId select r).ToList().LastOrDefault();
                int valRowId = validRow.Id;

                List<Cell> cl = (from c in db.Cell where c.RowId == valRowId && c.Number == colNum select c).ToList();
                #endregion

                /*var chartQuery = (from ad in db.AnalyticData
                                  where ad.Id == analyticDataId
                                  select new
                                  {
                                      AnalyticId = ad.Id,
                                      Type = ad.TypeId
                                  }).ToList();*/
                int valModalId = (int)cl[0].ModalViewId;

                ModalView modalQuery = (from m in db.ModalView where m.Id == valModalId select m).ToList().LastOrDefault();
                ChartInfoGetter cellsGetter = new ChartInfoGetter();

                List<ChartInfo> infos = cellsGetter.GetChartInfo(modalQuery);

                List<Object> charts = new List<Object>();
                foreach (var item in infos)
                {
                    Object obj = new Object();
                    obj = (Object)DatabaseToModelConverter.InitChart(item.AnalyticDataId, item.TypeId);
                    if (obj != null) { charts.Add(obj); }
                }

                
                List<Object> jsonChartModels = new List<Object>();

                foreach (var item in charts)
                {
                    Object obj = converter.Convert(item, item.GetType().ToString());
                    if (obj != null) { jsonChartModels.Add(obj); }
                }

                

                JavaScriptSerializer serializer = new JavaScriptSerializer();

                chartInfo = serializer.Serialize(jsonChartModels);


                return chartInfo;
            }
            catch (Exception exception)
            {
                return "";
            }
        }

        [HttpPost]
        public string GetCharts(string modal)
        {
            try
            {
                string chartInfo = "";
                int modalId = Int32.Parse(modal);

                ChartToJsonModelConverter converter = new ChartToJsonModelConverter();

                var db = new LandauEntities();


                ModalView modalQuery = (from m in db.ModalView where m.Id == modalId select m).ToList().LastOrDefault();
                ChartInfoGetter cellsGetter = new ChartInfoGetter();

                List<ChartInfo> infos = cellsGetter.GetChartInfo(modalQuery);

                List<Object> charts = new List<Object>();
                foreach (var item in infos)
                {
                    Object obj = new Object();
                    obj = (Object)DatabaseToModelConverter.InitChart(item.AnalyticDataId, item.TypeId);
                    if (obj != null) { charts.Add(obj); }
                }


                List<Object> jsonChartModels = new List<Object>();

                foreach (var item in charts)
                {
                    Object obj = converter.Convert(item, item.GetType().ToString());
                    if (obj != null) { jsonChartModels.Add(obj); }
                }



                JavaScriptSerializer serializer = new JavaScriptSerializer();

                chartInfo = serializer.Serialize(jsonChartModels);


                return chartInfo;
                return "";
            }
            catch (Exception exception)
            {
                return "";
            }
        }

        public FileResult ExportDocument(string id)
        {
            try
            {
                Document = DatabaseToModelConverter.GetDocumentFromDatabase(Int32.Parse(id));

                XlsxExport.Models.XModels.XDocument dllDoc = new XlsxExport.Models.XModels.XDocument();
                ToLibraryXDocumentConverter converter = new ToLibraryXDocumentConverter();
                dllDoc = converter.Convert(Document);
                XlsxExport.Exporter exporter = new XlsxExport.Exporter();
                FileInfo file = exporter.GenerateXls(dllDoc);

                byte[] fileBytes = System.IO.File.ReadAllBytes(file.ToString());
                return File(fileBytes, System.Net.Mime.MediaTypeNames.Application.Octet, file.Name);
            }
            catch (Exception exception)
            {
                return null;
            }

        }

        [HttpPost]
        public void ImportDocument(string data)
        {
            try
            {

            }
            catch (Exception exception)
            {

            }
        }

        public void SetCurrentId(string id)
        {
            try
            {
                Id = Int32.Parse(id);
            }
            catch (Exception exception)
            {

            }
        }

        /// <summary>
        /// Getting border styles for 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public string GetBorders(string id)
        {
            try
            {
                List<XBorder> borders = DatabaseToModelConverter.InitBorders(Int32.Parse(id));

                List<EnterpriseSheetBorder> esBorders = ConverterToEnterpriseSheetModel.ConvertBorders(borders);

                JavaScriptSerializer serializer = new JavaScriptSerializer();

                string bordersJson = serializer.Serialize(esBorders);

                return bordersJson;

            }
            catch (Exception exception)
            {
                return null;
            }
        }

    }
}
