﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Landau.Models.UserRoles
{
    /// <summary>
    /// 
    /// </summary>
    public class UserRolesModel
    {
        public int Id { get; set; }
        public string UserRole { get; set; }

    }
}