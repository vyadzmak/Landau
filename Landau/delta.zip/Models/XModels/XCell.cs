﻿using System;
using System.Drawing;
using Landau.Helper;

namespace Landau.Models.XModels
{
    public class XCell
    {
        #region fields
        public int Id { get; set; }

        public Guid Guid { get; set; }

        public int Number { get; set; }

        public string Value { get; set; }

        public bool IsButton { get; set; }

        public XStyle Style { get; set; }

        public XComment Comment { get; set; }

        public XFormat Format { get; set; }

        public XCalc Calculation { get; set; }


        #endregion

    

        #region constructors
        /// <summary>
        /// XCell's constructor
        /// </summary>
        /// <param name="id"></param>
        /// <param name="number"></param>
        /// <param name="value"></param>
        public XCell(int id, int number, string value, XStyle style, XComment comment, XFormat format, XCalc calculation)
        {
            try
            {
                Id = id;
                Number = number;
                Value = value;
                Style = style;
                Comment = comment;
                Format = new XFormat("","");
                Calculation = new XCalc(false);
            }
            catch (Exception exception)
            {

            }
        }


        /// <summary>
        /// XCell's constructor
        /// </summary>
        public XCell(int id, int number, string value)
        {
            try
            {
                NewIdAndNumberGetter getter = new NewIdAndNumberGetter();
                Id = id;
                Number = number;
                Value = value;
                Style = new XStyle(getter.GetNewStyleId(), 12, "normal", null, null, "normal", null, "#ffffff", "#000000", 0, null, null);
                Comment = new XComment(getter.GetNewCommentId(), null);
                Format = new XFormat(null, null);
                Calculation = new XCalc(false);
                IsButton = false;

            }
            catch (Exception exception)
            {

            }

        }

        /// <summary>
        /// Empty XCell's constructor
        /// </summary>
        public XCell()
        {
            try
            {

            }
            catch (Exception exception)
            {

            }

        }
        
        #endregion

    }
}