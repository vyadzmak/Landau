﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Landau.Models.XModels
{
    public class XProject
    {
        public int Id;
        public string Date;
    }
}