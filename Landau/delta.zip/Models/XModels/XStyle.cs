﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Landau.Helper;

namespace Landau.Models.XModels
{
    public class XStyle
    {
        public int Id { get; set; }
        public string Align { get; set; }
        public string FontWeight { get; set; }

        public string FontFamily { get; set; }

        public int FontSize { get; set; }

        public string FontStyle { get; set; }

        public bool Underline { get; set; }

        public bool Overline { get; set; }

        public bool Strike { get; set; }

        public string BackgroundColor { get; set; }

        public string FontColor { get; set; }

        public int Height { get; set; }

        public int Width { get; set; }

        public int Indent { get; set; }

        public string DecorLine { get; set; }

        public int DefautFontSize = 10;

         /// <summary>
        /// XCell's constructor
        /// </summary>
        /// <param name="id"></param>
        /// <param name="align"></param>
        /// <param name="fontSize"></param>
        /// <param name="weight"></param>
        /// <param name="width"></param>
        /// <param name="height"></param>
        /// <param name="style"></param>
        /// <param name="family"></param>
        /// <param name="back"></param>
        /// <param name="fontColor"></param>
        /// <param name="decorLine"></param>
        public XStyle (
            int id,           // 1
            int? fontSize,    // 2
            string weight,    // 3
            int? width,       // 4
            int? height,      // 5 
            string style,     // 6
            string family,    // 7
            string back,      // 8
            string fontColor, // 9
            int indent,       // 10
            string align,     // 11
            string decorLine  // 12
            ) 
        {
            try
            {
                Id = id;

                if (fontSize != null)
                {
                    FontSize = CellPropertiesValidator.FontSizeValidate((int)fontSize);
                }
                else
                {
                    FontSize = DefautFontSize;
                }

                if (weight != null)
                {
                    FontWeight = CellPropertiesValidator.FontWeightValidate(weight);
                }

                if (style != null)
                {
                    FontStyle = CellPropertiesValidator.FontStyleValidate(style);
                }

                if (style != null)
                {
                    FontFamily = family;
                }

                if (back != null)
                {
                    BackgroundColor = back;
                }

                if (fontColor != null)
                {
                    FontColor = fontColor;
                }

                Height = CellPropertiesValidator.CellHeightValidate(height);

                Width = CellPropertiesValidator.CellWidthValidate(width);

                Indent = indent;

                Align = align;

                DecorLine = decorLine;
            }
            catch (Exception exception)
            {

            }
        }
    }
}
