﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Landau.Models.Modal.Table
{
    public class ModalCellJson
    {
        public int id { get; set; }

        public int number { get; set; }

        public string value { get; set; }
        public int cellId { get; set; }

        public ModalCellJson(int id, int number, string value, int cellId)
        {
            this.id = id;
            this.number = number;
            this.value = value;
            this.cellId = cellId;

        }

        public ModalCellJson(int id, int number, string value)
        {
            this.id = id;
            this.number = number;
            this.value = value;

        }
    }
}