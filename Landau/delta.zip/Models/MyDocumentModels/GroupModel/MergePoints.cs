﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Landau.Models.MyDocumentModels.GroupModels
{
    public class MergePoints
    {
        public List<int> Points;

        public MergePoints()
        {
            Points = new List<int>();
        }
    }
}