﻿usersApp.controller("docsController", function ($scope, $http, $rootScope) {

    function pageiantion() {

        $scope.currentPage = 0;

        $scope.range = function() {

            var rangeSize = Math.ceil($scope.filteredContact.length / $scope.itemsPerPage);
            var ret = [];
            var start;
            start = $scope.currentPage;

            if (start > $scope.pageCount() - rangeSize) {
                start = $scope.pageCount() - rangeSize + 1;

            }

            for (var i = start; i < start + rangeSize; i++) {

                ret.push(i);
            }
            return ret;
        };
        $scope.pageCount = function() {

            return Math.ceil($scope.filteredContact.length / $scope.itemsPerPage) - 1;
        };

        $scope.prevPage = function() {
            if ($scope.currentPage > 0) {
                $scope.currentPage--;
            }
        };

        $scope.prevPageDisabled = function() {
            return $scope.currentPage === 0 ? "disabled" : "";
        };


        $scope.nextPage = function() {
            if ($scope.currentPage < $scope.pageCount()) {
                $scope.currentPage++;
            }
        };

        $scope.nextPageDisabled = function() {
            return $scope.currentPage === $scope.pageCount() ? "disabled" : "";
        };

        $scope.setPage = function(n) {
            $scope.currentPage = n;
        };
    }

   
    $scope.showOpen = false;
    $scope.isRowClicked = {
        clicked: false
    };
    $scope.getDocList = function() {
        $http({
            method: "GET"
        }).success(function(list) {
                url: urlGetDocumentsList,
                    $scope.DocumentsList = JSON.parse(JSON.stringify(list));
            }
        );
    };

  
    $rootScope.$on("CallOrderForUser", function () {
       
$scope.getOrdersList(); 
});

    $scope.getOrdersList = function () {

        $http({
            url: urlGetOrdersList,
            method: "GET"
        }).success(function(list) {
            $scope.OrdersList = JSON.parse(JSON.stringify(list));
            $('#dvLoading').hide();
        });
    };
    angular.element(document).ready(function() {
        $scope.getDocList();
      
        $scope.getOrdersList();
    });
    $scope.getDocument = function(id) {

        $http({
            url: urlGetDocument,
            method: "POST",
            data: { 'id': id }
        }).success(function(doc) {
            $scope.Doc = JSON.parse(JSON.parse(JSON.stringify(doc)));
            $scope.Id = $scope.Doc.Id;
            return $scope.Doc;
        });
    };
    $scope.execute = function() {
        $scope.isRowClicked = true;
    }
    $scope.getId = function(id) {
        $scope.Id = id;
        $http({
            url: urlSetId,
            method: "POST",
            data: { 'id': id }
        });
    };
    $scope.exportDocument = function() {
        $http({
            url: "",
            method: "POST",
            data: { 'id': $scope.Id }
        }).success(function(response) {
            window.location = "/Home/ExportDocument?id=" + $scope.Id;

        });
    }
    $scope.importDocument = function() {
        $scope.info = document.getElementById("file").files[0];
        $http({
            url: urlImportDocument,
            method: "POST",
            data: { 'data': $scope.info }
        }).success(function(response) {

        });

    }

    $scope.showOpenField = function() {
        $scope.showOpen = true;
    }
   
});

    