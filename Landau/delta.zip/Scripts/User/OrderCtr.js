﻿usersApp.controller("OrderCtr", function($scope, $http) {
   

        $scope.currentPage = 0;

        $scope.range = function () {

            var rangeSize = Math.ceil($scope.filteredOrder.length / $scope.itemsPerPage);
            var ret = [];
            var start;
            start = $scope.currentPage;

            if (start > $scope.pageCount() - rangeSize) {
                start = $scope.pageCount() - rangeSize + 1;

            }

            for (var i = start; i < start + rangeSize; i++) {

                ret.push(i);
            }
            return ret;
        };
        $scope.pageCount = function () {

            return Math.ceil($scope.filteredOrder.length / $scope.itemsPerPage) - 1;
        };

        $scope.prevPage = function () {
            if ($scope.currentPage > 0) {
                $scope.currentPage--;
            }
        };

        $scope.prevPageDisabled = function () {
            return $scope.currentPage === 0 ? "disabled" : "";
        };


        $scope.nextPage = function () {
            if ($scope.currentPage < $scope.pageCount()) {
                $scope.currentPage++;
            }
        };

        $scope.nextPageDisabled = function () {
            return $scope.currentPage === $scope.pageCount() ? "disabled" : "";
        };

        $scope.setPage = function (n) {
            $scope.currentPage = n;
        };
    
    
})