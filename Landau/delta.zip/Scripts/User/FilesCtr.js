﻿/// <reference path="../../Views/Partial/DocumentsTable.cshtml" />

function UploadProgress(evt) {
    if (evt.lengthComputable) {
        var percentComplete = Math.round(evt.loaded * 100 / evt.total);
        $("#uploading").text("Загрузка файлов"+" "+percentComplete + "% ");
        
    }
}

function UploadFailed(evt) {
    alert("There was an error attempting to upload the file.");
}

function UploadCanceled(evt) {
    alert("The upload has been canceled by the user or the browser dropped the connection.");
}


usersApp.controller("FileCtr", function ($scope, $http,$interval,$rootScope, contactFactory) {
   // $scope.showdvLoading = true;
   
    function uploadComplete(fileInput, idList) {
        $scope.checktable = true;

        for (i = 0; i < fileInput.files.length; i++) {
            $scope.Files.push({
                FileName: fileInput.files[i].name,
                State: "загружен"
            });
        }
        console.log(idList);
        $scope.Contact = [];
        contactFactory.GetDocuments().then(function (d) {
            $scope.Contact = d.data;

       
        });

    }

    function pageiantion() {

        $scope.currentPage = 0;

        $scope.range = function() {

            var rangeSize = Math.ceil($scope.filteredContact.length / $scope.itemsPerPage);
            var ret = [];
            var start;
            start = $scope.currentPage;

            if (start > $scope.pageCount() - rangeSize) {
                start = $scope.pageCount() - rangeSize + 1;

            }

            for (var i = start; i < start + rangeSize; i++) {

                ret.push(i);
            }
            return ret;
        };
        $scope.pageCount = function() {

            return Math.ceil($scope.filteredContact.length / $scope.itemsPerPage) - 1;
        };

        $scope.prevPage = function() {
            if ($scope.currentPage > 0) {
                $scope.currentPage--;
            }
        };

        $scope.prevPageDisabled = function() {
            return $scope.currentPage === 0 ? "disabled" : "";
        };


        $scope.nextPage = function() {
            if ($scope.currentPage < $scope.pageCount()) {
                $scope.currentPage++;
            }
        };

        $scope.nextPageDisabled = function() {
            return $scope.currentPage === $scope.pageCount() ? "disabled" : "";
        };

        $scope.setPage = function(n) {
            $scope.currentPage = n;
        };
    }


    $scope.$watch("query", function() {

        $scope.currentPage = 0;
    });
    $scope.$watch("selectedformat", function() {

        $scope.currentPage = 0;
    });


    
    function loadFile(formdata, fileInput) {
        console.log("Form");
        var xhr = new XMLHttpRequest();
        xhr.upload.addEventListener("progress", function(evt) { UploadProgress(evt); }, false);
        xhr.addEventListener("load", function(idList) { uploadComplete(fileInput, idList); }, false);
        xhr.addEventListener("error", function(evt) { UploadFailed(evt); }, false);
        xhr.addEventListener("abort", function(evt) { UploadCanceled(evt); }, false);
        xhr.open("POST", "Documents/Upload");
        xhr.send(formdata);
        $scope.showLink = false;

        $scope.descriptioncheck = false;
        return false;
    }


    $scope.LoadFileData = function() {

        if ($scope.descriptioncheck === true) {

            if ($scope.value.$invalid) {
              
                $scope.submitted = true;

            } else {
                
              
                var formdata = new FormData(); //FormData object
                var fileInput = document.getElementById("etlfileToUpload");
                $scope.Files = [];
                for (i = 0; i < fileInput.files.length; i++) {

                    console.log(fileInput.files.length);
                    formdata.append("files", fileInput.files[i]);
                    formdata.append("description", $scope.Description);


                }
               
                loadFile(formdata, fileInput);
                
            }
        } else {
          
            var formdatanew = new FormData(); //FormData object
            var fileInputnew = document.getElementById("etlfileToUpload");
            $scope.Files = [];
            for (i = 0; i < fileInputnew.files.length; i++) {

                console.log(fileInputnew.files.length);
                formdatanew.append("files", fileInputnew.files[i]);
                formdatanew.append("description", '');


            }
            loadFile(formdatanew, fileInputnew);
        }


    };
   
    $scope.confirm = function() {
       
        $http.get("Documents/WaitConfirm").success(function(data) {
            $scope.Files = [];

            $scope.Files = data;
            $rootScope.$emit("CallOrderForUser", {});

       
        });

    }

    $scope.getListOfDocsBId = function(id) {
        $scope.showdvLoading = true;

        $scope.Contact = [];
        console.log(id);
        contactFactory.GetDocuments(id).then(function(d) {
            console.log(d.data);
            $scope.Contact = d.data;
            $scope.showdvLoading = false;
            pageiantion();
         

       
        });
        $scope.TypeDocument = [];
        contactFactory.GetTypeDocument().then(function(d) {
            $scope.TypeDocument = d.data;


       
        });

        $scope.Order = [];

        contactFactory.GetOrders(id).then(function(d) {
            console.log(d.data);
            $scope.Order = d.data;
        //    $scope.showdvLoading = false;

       
        });

    }
 

    $scope.showDescription = function() {

        var fileInput = document.getElementById("etlfileToUpload");

        if (fileInput.files.length > 0) {
            $scope.showLink = true;
            $scope.Description = [];
        } else {
            $scope.showLink = false;
        }


    };
    pageiantion();

    $scope.sortField = undefined;
    $scope.reverse = false;
    $scope.sort = function(fieldName) {

        if ($scope.sortField === fieldName) {

            $scope.reverse = !$scope.reverse;

        } else {

            $scope.sortField = fieldName;
            $scope.reverse = false;
        }
    };
    $scope.isSortUp = function(fieldName) {
        return $scope.sortField === fieldName && !$scope.reverse;
    };
    $scope.isSortDown = function(fieldName) {
        return $scope.sortField === fieldName && $scope.reverse;
    };

    $scope.getListOfDocsBIdForUser = function (id) {
        console.log("123");
        $scope.showdvLoading = true;
        $scope.Docs = [];
   //     $('#dvLoading').show();
   
        contactFactory.GetDocuments(id).then(function (d) {
           
            console.log(d.data);
            $scope.Docs = d.data;
           
            $scope.showdvLoading = false;
        //    pageiantionforuser();

        
        });
        $scope.TypeDocument = [];
        contactFactory.GetTypeDocument().then(function (d) {
            $scope.TypeDocument = d.data;
            console.log("type");
            

       
        });
      
    }
  


});
usersApp.filter("offset", function () {
        return function(input, start) {

            return input.slice(start);
        };
    });
usersApp.factory("contactFactory", function ($http) {
                var fac = {};
   
              
                fac.GetDocuments = function (id) {
                   
                    return $http(
                    {
                        url: "Documents/GetDocuments?id="+id,
                        method: "GET"

                    });
                };
                fac.GetTypeDocument = function() {
                    return $http(
                    {
                        url: "Documents/GetDocumentType",
                        method: "GET"

                    });
                };
                fac.GetOrders = function (id) {
                    return $http(
                    {
                        url: "Documents/GetOrders?id=" + id,
                        headers: {
                            'Content-Type': 'json'
                        },
                        method: "GET"

                    });
                }
                
                return fac;
            });
    