﻿usersApp.controller("renderController", function doit($scope) {
    console.log($scope.showdvLoading);
    //$scope.spinnerVisible = true;
   
    console.log($scope.showdvLoading);
    $scope.isDocRow = false;
    $scope.getElement = function (id) {
        $scope.el = Ext.get(id);
    }
    $scope.getSign = function (id) {
        if (id == "docRow") {
            $scope.isDocRow = true;
        }
    }
    $scope.render = function (doc) {

        SCONFIG.setupDir('');

        while (true) {
            SHEET_API = Ext.create('EnterpriseSheet.api.SheetAPI', {
                openFileByOnlyLoadDataFlag: true
            });

            if (SHEET_API != 'undefined') { break; }
        }

        while (true) {
            SHEET_API_HD = SHEET_API.createSheetApp({
                renderTo: 'sheet-markup',
                style: 'background:white;border-left:1px solid silver;',
                height: '100%'
            });

            if (SHEET_API_HD != 'undefined') { break; }

        }

        document.documentElement.style.background = 'none';
        Ext.getBody().setStyle('background-image', 'none');

        var store = SHEET_API_HD.store;
        store.on('valuechange', function (sheetId, row, col, modified, deleted, origin, current, store) {
            $.ajax({
                type: "POST",
                url: urlIndex,
                data: { 'sheetNumberVar': sheetId, 'rowVar': row, 'colVar': col, 'afterChangesVar': current.data, 'originVar': JSON.stringify(origin), 'current': JSON.stringify(current) }

            });
        });
        
    };

    Ext.onReady(function () {
        var el = Ext.get('piece');
        var iter = 0;
        
        el.on('click', function (e, target, options) {
            $("#sv").append("<div id=\"dvLoading\"></div>");
            $scope.Doc = 'undefined';
            currentDocId = $scope.Id;
            if ($scope.isDocRow) {
                $.ajax({
                    type: "POST",
                    url: urlGetDocument,
                    data: { 'id': $scope.Id }
                }).then(function (result) {
                    $scope.Doc = JSON.parse(JSON.parse(JSON.stringify(result)));
                    ///$scope.Doc = JSON.parse(JSON.parse(JSON.stringify(result)));
                }).then(function () {

                    $.ajax({
                        type: "POST",
                        url: urlGetBorders,
                        data: { 'id': $scope.Id } // На контроллере мы получим все id шитов, принадлежащие данному документу, а по id шитов извлечем границы
                    }).then(function (result) {
                        $scope.Borders = result;
                        $scope.ParsedBorders = JSON.parse(result);
                    }).then(function () {
                        if (iter == 1) {
                            $scope.render();
                            SHEET_API.loadData(SHEET_API_HD, $scope.Doc, function () {
                                for (var i = 0; i < $scope.ParsedBorders.length; i++) {
                                    var singleBorderStr = JSON.stringify($scope.ParsedBorders[i]);
                                    var ranges = singleBorderStr.match(/(\[\[\d+\,\d+\,\d+\,\d+\,\d+\]\])/);
                                    var range = JSON.parse(ranges[0]);

                                    var singleBorderWithoutRange = singleBorderStr.replace(/(\,\"range":\{\"Range\":\[\[\d+\,\d+\,\d+\,\d+\,\d+\]\]\})/, "");
                                    singleBorderWithoutRange = JSON.parse(singleBorderWithoutRange);
                                    SHEET_API.applyCellsBorder(SHEET_API_HD, range, singleBorderWithoutRange);
                                }
                            });
                            $("div").remove("#dvLoading");
                        }
                        else {
                            SHEET_API.loadData(SHEET_API_HD, $scope.Doc, function () {
                                for (var i = 0; i < $scope.ParsedBorders.length; i++) {
                                    var singleBorderStr = JSON.stringify($scope.ParsedBorders[i]);
                                    var ranges = singleBorderStr.match(/(\[\[\d+\,\d+\,\d+\,\d+\,\d+\]\])/);
                                    var range = JSON.parse(ranges[0]);

                                    var singleBorderWithoutRange = singleBorderStr.replace(/(\,\"range":\{\"Range\":\[\[\d+\,\d+\,\d+\,\d+\,\d+\]\]\})/, "");
                                    singleBorderWithoutRange = JSON.parse(singleBorderWithoutRange);
                                    SHEET_API.applyCellsBorder(SHEET_API_HD, range, singleBorderWithoutRange);
                                }
                            });
                            $("div").remove("#dvLoading");
                        }
                    });



                    iter = iter + 1;
                    console.log(iter);
                });
            }

       


        }, this, {
            delegate: 'tr'
        });

        

        
    });

});