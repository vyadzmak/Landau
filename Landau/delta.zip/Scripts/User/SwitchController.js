﻿usersApp.controller("switchController", function ($scope) {
    $scope.showdvLoading = true;
   
    $scope.User1Flag = true;
    $scope.User2Flag = false;
    $scope.User3Flag = false;
    $scope.RequestModeFlag = false;

    $scope.PartialsStates = [true,  // 0 - Request table
                             false, // 1 - Area chart
                             false, // 2 - Responsive timeline
                             false, // 3 - Notification table
                             false, // 4 - Donut chart
                             false, // 5 - Chat
                             false, // 6 - Documents table
                             false, // 7 - Sheets
                             false,  // 8 - Order table for user
                             false  // 9 - New order form
    ];

    $scope.switchModes = function (id) {
        var s = JSON.parse(id);
        switch (s) {
            case 0: $scope.User3Flag = true;
                $scope.User1Flag = false;
                $scope.User2Flag = false;
                $scope.RequestModeFlag = false;
                $scope.switchPartials(4);
                break;

            case 1: $scope.User2Flag = true;
                $scope.User1Flag = false;
                $scope.User3Flag = false;
                $scope.RequestModeFlag = false;
                $scope.switchPartials(2);
                break;
            case 2:

                $scope.User1Flag = true;
                $scope.User2Flag = false;
                $scope.User3Flag = false;
                $scope.RequestModeFlag = false;
                $scope.switchPartials(0);
                break;
            case 3: $scope.RequestModeFlag = true;
                $scope.User2Flag = false;
                $scope.User3Flag = false;
                $scope.switchPartials(6);
                break;
        }
    };
    switchName = function () {
        $scope.UserName = names[$scope.UserId];
    }

    $scope.switchPartials = function (partialId) {
        for (var i = 0; i < $scope.PartialsStates.length; i++) {
            $scope.PartialsStates[i] = false;
        }

        $scope.PartialsStates[partialId] = true;
        setTimeout(function () {
            for (var i = 0; i <= 14; i++) {
                $("#side" + i).attr("style", "");
            }
        }, 100);
    }

    $scope.isSwitchedOn = function (id) {
        return $scope.PartialsStates[id];
    }

    angular.element(document).ready(function() {
        $scope.switchModes(mode);
        $scope.showdvLoading = false;
    });
    

});