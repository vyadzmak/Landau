﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Landau.DB;

namespace Landau.Helper
{
    public static class LogHelper
    {
        public static void AddLog(string message)
        {
            try
            {
                LandauEntities entities = new LandauEntities();
                LogTable table = new LogTable();
                table.DateTime = DateTime.Now;
                table.Message = message;
                entities.LogTable.Add(table);
                entities.SaveChanges();

            }
            catch (Exception)
            {
            }
        }
    }
}