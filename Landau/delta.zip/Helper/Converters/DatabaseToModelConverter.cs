﻿using System;
using System.Collections.Generic;
using System.Linq;
using Landau.DB;
using Landau.Helper;
using Landau.Models.XModels;
using Landau.Models.Chart;
using Landau.Models.Modal.Table;
using Landau.Models.Modal.XLineChart;
using Landau.Models.Modal.StackedBarchart;
using Landau.Models.Modal.XNonStackedBarchart;


namespace Landau.Helper
{
    public class DatabaseToModelConverter
    {
        #region methods
        /// <summary>
        ///     init all sheets in current document
        /// </summary>
        /// <param name="document"></param>
        /// <param name="sheets"></param>
        /// <returns></returns>
        private static XDocument InitDocument(XDocument document)
        {
            try
            {
                var db = new LandauEntities();
                int docId = document.Id;
                //forming sheets
                var sheets = (from sheet in db.Sheet
                              where sheet.DocumentId == docId
                              select sheet).ToList();

                var analyticData = (from m in db.ModalView
                                    join c in db.Cell on m.Id equals c.ModalViewId select new 
                                    {
                                        Id = c.ModalViewId

                                    }).ToList();


                List<XFloating> floatings = new List<XFloating>();
                foreach (var sheet in sheets)
                {
                    var groups = (from gr in db.TableGroups where gr.SheetId == sheet.Id select gr).ToList();
                   
                    document.Sheets.Add(new XSheet(sheet.Id, sheet.Number, sheet.Name));
                   
                    XFloating xFloating = new XFloating();
                    xFloating.SheetNumber = sheet.Number;
                    xFloating.Name = "colGroup";

                    foreach (var groupItem in groups)
                    {
                        xFloating.Groups.Add(new XGroup(groupItem.Id, groupItem.StartGroup, groupItem.EndGroup, "colGroups", "colgroup", 1));
                    }

                    if (groups.Count != 0)
                    {
                        document.Floatings.Add(xFloating);
                    }
                }

                for (var i = 0; i < document.Sheets.Count; i++)
                {
                    var sheet = document.Sheets[i];
                    var body = (from s in db.Body where s.SheetId == sheet.Id select s).FirstOrDefault();
                    document.Sheets[i].Body = new XBody(body.Id, new List<XRow>());

                    //init rows
                    var rows = (from s in db.Row where s.BodyId == body.Id select s).ToList();
                    for (var j = 0; j < rows.Count; j++)
                    {
                        var xRow = new XRow(rows[j].Id, rows[j].Number);
                        document.Sheets[i].Body.Rows.Add(xRow);

                        //init cells
                        var cells = (from c in db.Cell where c.RowId == xRow.Id join 
                                     st in db.CellStyles on c.Id equals st.CellId into ps
                                     from p in ps.DefaultIfEmpty()
                                     //join
                                    // com in db.CellComments on c.Id equals com.CellId
                                     select new 
                                     {
                                         Id = c.Id,
                                         ModalId = c.ModalViewId,
                                         StyleId = p.Id,
                                         Number = c.Number,
                                         Value = c.Value,
                                         Height = p.Height,
                                         Width = p.Width,
                                         DFM = p.DFM,
                                         Indent = p.Indent,
                                         Align = p.Align,
                                         DataFormat = p.CellDataFormat,
                                         CellType = p.CellDataFormat,
                                         FontColor = p.FontColor,
                                         FontSize = p.FontSize,
                                         BackgroundColor = p.BackgroundColor,
                                         FontWeight = p.FontWeight,
                                         FontStyle = p.FontStyle,
                                        // Comment = com.Message,
                                         //CommentId = com.Id,
                                         FontFamily = p.FontFamily,
                                         Calc = p.Calc,
                                         DecoreLine = p.DecorLine
                                     }).ToList();

                        foreach (var item in cells)
                        {
                            XCalc xCalc = new XCalc(false);
                            if (item.Calc != null)
                            {
                                xCalc = new XCalc((bool) item.Calc);
                            }
                            XFormat xFormat = new XFormat (item.DataFormat, item.DFM);
                          //  XComment xComment = new XComment(item.CommentId, item.Comment);
                            //XStyle xStyle = new XStyle(item.FontSize, item.FontWeight, item.Width, item.Height, item.FontStyle, 
                            //    item.FontFamily, item.BackgroundColor, item.FontColor, item.Indent);

                            XStyle xStyle = new XStyle(item.StyleId, item.FontSize, item.FontWeight, item.Width, item.Height, item.FontStyle, item.FontFamily,
                                item.BackgroundColor, item.FontColor, (int)item.Indent, item.Align, item.DecoreLine);

                            XCell xCell = new XCell(item.Id, item.Number, item.Value, xStyle, null/*xComment*/, xFormat, xCalc);

                            foreach (var analyticItem in analyticData)
                            {
                                if (analyticItem.Id == item.ModalId)
                                {
                                    xCell.IsButton = true;
                                }
                            }

                            document.Sheets[i].Body.Rows[j].Cells.Add(xCell);

                        }
                    }
                }

                return document;
            }
            catch (Exception exception)
            {
                LogHelper.AddLog("Error. InitDocument. Error:" + exception.Message + " InnerException: " + exception.InnerException.Message);

                return document;
            }
        }

        /// <summary>
        /// Getting borders for whole current document by it's id
        /// </summary>
        /// <param name="docId"></param>
        /// <returns></returns>
        public static List<XBorder> InitBorders(int docId)
        {
            try
            {
                LandauEntities db = new LandauEntities();

                List<XBorder> currentSheetBorders = new List<XBorder>();

                var sheets = from sh in db.Sheet where sh.DocumentId == docId select sh;
                var borders = (from bs in db.BorderStyle 
                               join sh in sheets on bs.SheetId equals sh.Id
                               join bp in db.BorderPosition on bs.PositionId equals bp.Id
                               join lt in db.LineType on bs.LineTypeId equals lt.Id 
                               select new {
                                   Id = bs.Id,
                                   StartRow = bs.StartRowNum,
                                   StartCol = bs.StartColNum,
                                   EndRow = bs.EndRowNum,
                                   EndCol = bs.EndColNum,
                                   Position = bp.Name,
                                   Width = bs.Width,
                                   LineType = lt.Name,
                                   Color = bs.Color,
                                   SheetId = bs.SheetId,
                                   SheetNumber = sh.Number
                               }).ToList();

                foreach (var sheetItem in sheets)
                {
                    foreach (var borderItem in borders)
                    {
                        if (borderItem.SheetId == sheetItem.Id) 
                        {
                            currentSheetBorders.Add(new XBorder(borderItem.Id, borderItem.StartRow, borderItem.EndRow,
                                borderItem.StartCol, borderItem.Position, CellPropertiesValidator.BorderWidthValidator(borderItem.Width), borderItem.LineType, borderItem.EndCol, 
                                borderItem.Color, borderItem.SheetNumber));
                        }
                    }
                }

                return currentSheetBorders;
            }
            catch (Exception exception)
            {
                return null;
            }
        }

        /// <summary>
        /// Get document from database by Id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public static XDocument GetDocumentFromDatabase(int id)
        {
            try
            {
                var db = new LandauEntities();

                Documents documentFromDb = (from doc in db.Documents where (doc.Id == id) select doc).FirstOrDefault();

                //returning document formed in InitDocument method
                return InitDocument(new XDocument(documentFromDb.Id, documentFromDb.FileName));;
            }
            catch (Exception exception)
            {
                LogHelper.AddLog("Error. GetDocumentFromDatabase. Error:" + exception.Message + " InnerException: " + exception.InnerException.Message);

                return null;
            }
        }

        /// <summary>
        /// Gets the Id of the last Document in database
        /// </summary>
        /// <returns></returns>
        public static int GetLastDocumentId()
        {
            try
            {
                LandauEntities db = new LandauEntities();
                List<Documents> documents = (from doc in db.Documents select doc).ToList();
                int id = documents[documents.Count - 1].Id;
                return id;
            }
            catch (Exception exception)
            {
                return 0;
            }
        }

        public static XLineChart InitLineChart(int id, Models.Modal.Position position)
        {
            try 
            {
                var db = new LandauEntities();
                LineChart lineChartQuery = (from lc in db.LineChart where lc.AnalyticDataId == id select lc).ToList().LastOrDefault();
                List<LineChartElement> lineChartElementQuery = (from lce in db.LineChartElement where lce.LineChartId == lineChartQuery.Id select lce).ToList();
                List<LineChartPoint> lineChartPointQuery = (from lcp in db.LineChartPoint where 1 == 1 select lcp).ToList();



                XLineChart xLineChart = new XLineChart(lineChartQuery.Id, lineChartQuery.Description, position, lineChartQuery.Type);

                foreach (var elementItem in lineChartElementQuery)
                {
                    List<LineChartPoint> pointsQuery = (from lcp in lineChartPointQuery where lcp.LineChartElementId == elementItem.Id select lcp).ToList();
                    XLineChartElement element = new XLineChartElement(elementItem.Id, elementItem.Description);
                    List<XPointLineChart> points = new List<XPointLineChart>();
                    foreach (var pointItem in pointsQuery)
                    {
                        points.Add(new XPointLineChart(pointItem.Id, pointItem.PositionX,
                            double.Parse(pointItem.PositionY), pointItem.Category));
                    }
                    element.Points = points;
                    xLineChart.Elements.Add(element);
                }
                
                return xLineChart;
            }
            catch (Exception exception)
            {
                return null;
            }
        }

        public static Object InitChart(int id, int type)
        {
            try
            {
                var db = new LandauEntities(); 
                var modalCell = (from mc in db.ModalViewCell
                                 join ad in db.AnalyticData on mc.Id equals ad.ModalViewCellId
                                 where ad.Id == id
                                 select new
                                 {
                                     Number = mc.Number,
                                     RowId = mc.RowId
                                 }).ToList().LastOrDefault();

                int rowId = modalCell.RowId;
                var modalRow = (from mr in db.ModalViewRow
                                where mr.Id == rowId
                                select new
                                {
                                    Number = mr.Number
                                }).ToList().LastOrDefault();

                Models.Modal.Position position = new Models.Modal.Position(modalRow.Number, modalCell.Number);
                if (type == 1)
                {
                    return (Object)InitPieChart(position, id);
                }

                if (type == 2)
                {
                    return (Object)InitLineChart(id, position);
                }

                if (type == 4)
                {
                    return (Object)InitModalTable(position, id);
                }

                if (type == 5)
                {
                    return (Object)InitStackedBarchart(position, id);
                }

                if (type == 1005)
                {
                    return (Object)InitNonStackedBarchart(position, id);
                }

                return null;
            }
            catch (Exception exception)
            {
                return null;
            }
        }

        public static XPieChart InitPieChart(Models.Modal.Position position, int id)
        {
            try
            {
                var db = new LandauEntities();
               
                var analyticDatas = (from ad in db.AnalyticData select ad).ToList();
                var pieCharts = (from pc in db.PieChart select pc).ToList();
                var chartElements = (from ce in db.PieChartElement select ce).ToList();
                List<XPieChart> pieChartsList = new List<XPieChart>();
                XPieChart pie = new XPieChart();
                
                foreach (var analyticDataItem in analyticDatas)
                {
                    if (analyticDataItem.Id == id && analyticDataItem.TypeId == 1)
                    {
                        foreach (var pieChartItem in pieCharts)
                        {
                            if (analyticDataItem.Id == pieChartItem.AnalyticDataId)
                            {
                                pie = new XPieChart(pieChartItem.Id, pieChartItem.Description, position);
                                pieChartsList.Add(pie);
                            }
                        }
                    }
                }

                foreach (var pieChart in pieChartsList)
                {
                    foreach (var pieElement in chartElements)
                    {
                        if (pieElement.PieChartId == pieChart.Id)
                        {
                            pieChart.Elements.Add(new XPieChartElement(double.Parse(pieElement.Value), pieElement.Description));
                        }
                    }
                }

                return pie;
            }
            catch (Exception exception)
            {
                return null;
            }
        }

        public static XStackedBarchart InitStackedBarchart(Models.Modal.Position position, int id)
        {
            try
            {
                var db = new LandauEntities();

                var analyticDatas = (from ad in db.AnalyticData select ad).ToList();
                var stackedCharts = (from sb in db.StackedBarchart select sb).ToList();
                var chartColumns = (from sc in db.StackedBarchartColumn select sc).ToList();
                var chartElements = (from se in db.StackedBarchartElement select se).ToList();
                XStackedBarchart barchart = new XStackedBarchart();

                foreach (var analyticDataItem in analyticDatas)
                {
                    if (analyticDataItem.Id == id && analyticDataItem.TypeId == 5)
                    { 
                        foreach (var stackedChartItem in stackedCharts)
                        {
                            if (stackedChartItem.AnalyticDataId == analyticDataItem.Id)
                            {
                                barchart = new XStackedBarchart(stackedChartItem.Id, stackedChartItem.Description, stackedChartItem.Title, position);
                                break;
                            }
                        }
                        break;
                    }
                }

                foreach (StackedBarchartColumn columnItem in chartColumns)
                {
                    if (columnItem.StackedBarChartId == barchart.Id)
                    {
                        XStackedBarchartColumn column = new XStackedBarchartColumn(columnItem.Id, columnItem.PositionX, columnItem.Description);
                        foreach (StackedBarchartElement elementItem in chartElements)
                        {
                            if (elementItem.BarchartColumnId == columnItem.Id)
                            {
                                column.Elements.Add(new XStackedBarchartElement(elementItem.Id, elementItem.Description,
                                    double.Parse(elementItem.Value), elementItem.Category));
                            }
                        }
                        barchart.Columns.Add(column);
                    }
                }

                return barchart;
            }
            catch (Exception exception)
            {
                return null;
            }
        }

        public static XNonStackedBarchart InitNonStackedBarchart(Models.Modal.Position position, int id)
         {
             try
             {
                 var db = new LandauEntities();

                 var analyticDatas = (from ad in db.AnalyticData select ad).ToList();
                 var stackedCharts = (from sb in db.NonStackedBarChart select sb).ToList();
                 var chartColumns = (from sc in db.NonStackedBarChartColumn select sc).ToList();
                 var chartElements = (from se in db.NonStackedBarChartElement select se).ToList();
                 XNonStackedBarchart barchart = new XNonStackedBarchart();

                 foreach (var analyticDataItem in analyticDatas)
                 {
                     if (analyticDataItem.Id == id && analyticDataItem.TypeId == 1005)
                     {
                         foreach (var stackedChartItem in stackedCharts)
                         {
                             if (stackedChartItem.AnalyticDataId == analyticDataItem.Id)
                             {
                                 barchart = new XNonStackedBarchart(stackedChartItem.Id, stackedChartItem.Description, position);
                                 break;
                             }
                         }
                         break;
                     }
                 }

                 foreach (NonStackedBarChartColumn columnItem in chartColumns)
                 {
                     if (columnItem.NonStackedBarchartId== barchart.Id)
                     {
                         XNonStackedBarchartColumn column = new XNonStackedBarchartColumn(columnItem.Id, columnItem.PositionX, columnItem.Description);
                         foreach (NonStackedBarChartElement elementItem in chartElements)
                         {
                             if (elementItem.NonStackedBarchartColumnId == columnItem.Id)
                             {
                                 column.Elements.Add(new XNonStackedBarchartElement(elementItem.Id, elementItem.Description,
                                     double.Parse(elementItem.Value), elementItem.Category));
                             }
                         }
                         barchart.Columns.Add(column);
                     }
                 }

                 return barchart;
             }
             catch (Exception exception)
             {
                 return null;
             }
         }


        public static ModalTable InitModalTable(Models.Modal.Position position, int id)
        {
            try
            {
                var db = new LandauEntities();

                //var cells = (from cm in db.CellModal select cm).ToList();
                //var rows = (from rm in db.RowModal select rm).ToList();
                //var bodies = (from bm in db.BodyModal select bm).ToList();
                var table = from tm in db.TableModal where tm.AnalyticDataId == id select tm;
                var bodies = (from bd in db.BodyModal
                              join t in table on bd.TableModalId equals t.Id select new 
                              {
                                  BodyId = bd.Id,
                                  Description = t.Description
                              }).ToList();

                ModalTable mTable = new ModalTable();
                foreach (var bodyItem in bodies)
                {
                    int bodyId = bodyItem.BodyId;

                    ModalBody mBody = new ModalBody(bodyItem.BodyId);
                    var rows = (from rm in db.RowModal where bodyItem.BodyId == rm.ModalBodyId select rm).ToList();
                    foreach (var rowItem in rows)
                    {
                        int rowId = rowItem.Id;
                        var cells = (from cm in db.CellModal where rowId == cm.RowModalId select cm).ToList();
                        ModalRow mRow = new ModalRow(rowId, (int)rowItem.Number);
                        foreach (var cellItem in cells)
                        {
                            if (cellItem.ModalViewId != null) { mRow.Cells.Add(new ModalCell(cellItem.Id, cellItem.Value, cellItem.Number, (int)cellItem.ModalViewId));  }
                            else { mRow.Cells.Add(new ModalCell(cellItem.Id, cellItem.Value, cellItem.Number)); }
                        }
                        mBody.Rows.Add(mRow);
                    }
                    mTable.Id = bodyId;
                    mTable.Body = mBody;
                    mTable.Description = bodyItem.Description;
                    mTable.Position = position;
                }

                return mTable;
            }
            catch (Exception exception)
            {
                return null;
            }
        }

#endregion
    }
}