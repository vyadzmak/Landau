﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Landau.Models.XModels;

namespace Landau.Helper
{
    public static class DocumentNavigationHelper
    {
        #region methods
        /// <summary>
        /// Returns sheet by index, or null, if not exists
        /// </summary>
        /// <param name="document"></param>
        /// <param name="number"></param>
        /// <returns></returns>
        public static XSheet GetSheetByNumber(XDocument document, int number)
        {
            try
            {
                foreach (var sheet in document.Sheets)
                {
                    if (sheet.Number == number)
                    {
                        return sheet;
                    }
                }

                return null;
            }
            catch (Exception)
            {
                return null;
            }
        }

        /// <summary>
        /// Returns row by index, returns null, if not exists
        /// </summary>
        /// <param name="sheet"></param>
        /// <param name="number"></param>
        /// <returns></returns>
        public static XRow GetRowbyNumber(XBody body, int number)
        {
            try
            {
                foreach (var row in body.Rows)
                {
                    if (row.Number == number)
                    {
                        return row;
                    }
                }

                return null;
            }
            catch (Exception)
            {
                return null;
            }
        }

        /// <summary>
        /// Returns cell by index, returns null, if not exists
        /// </summary>
        /// <param name="cell"></param>
        /// <param name="number"></param>
        /// <returns></returns>
        public static XCell GetCellByNumber(XRow row, int number)
        {
            try
            {
                foreach (var cell in row.Cells)
                {
                    if (cell.Number == number)
                    {
                        return cell;
                    }
                }

                return null;
            }
            catch (Exception)
            {
                return null;
            }
        }
        #endregion
    }
}