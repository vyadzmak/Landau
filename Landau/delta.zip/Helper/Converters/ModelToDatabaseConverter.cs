﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Migrations;
using System.Linq;
using System.Web;
using Landau.Models;
using Landau.Models.XModels;
using Landau.DB;


namespace Landau.Helper
{
    public class ModelToDatabaseConverter
    {
        public static void UpdateDatabase(XDocument document, XSheet sheet, XBody body, XRow row, XCell cell)
        {
            try
            {
                LandauEntities db = new LandauEntities();

                Cell cellNew;
                CellStyles cellStyleNew;
                CellComments cellCommentNew;
                Row rowNew;
                Sheet sheetNew;
                Body bodyNew;
                Document documentNew;

                cellNew = new Cell()
                {
                    Id = cell.Id,
                    Number = cell.Number,
                    RowId = row.Id,
                    Value = cell.Value
                };

                cellStyleNew = new CellStyles()
                {
                    Id = cell.Style.Id,
                    FontWeight = cell.Style.FontWeight,
                    FontSize = cell.Style.FontSize,
                    BackgroundColor = cell.Style.BackgroundColor,
                    FontColor = cell.Style.FontColor,
                    CellType = cell.Format.Format,
                    Align = cell.Style.Align,
                    Indent = (int)cell.Style.Indent,
                    DFM = cell.Format.Template,
                    Height = cell.Style.Height,
                    Width = cell.Style.Width,
                    FontStyle = cell.Style.FontStyle,
                    FontFamily = cell.Style.FontFamily,
                    Calc = cell.Calculation.IsFormula,
                    CellId = cell.Id,
                    DecorLine = cell.Style.DecorLine
                };

                cellCommentNew = new CellComments()
                {
                    Id = cell.Comment.Id,
                    Message = cell.Comment.Message,
                    CellId = cell.Id
                };

                db.CellComments.AddOrUpdate(cellCommentNew);
                db.CellStyles.AddOrUpdate(cellStyleNew);
                db.Cell.AddOrUpdate(cellNew);
                System.Console.WriteLine(cellNew.Id.ToString() + "/" + cellNew.Number.ToString());

                rowNew = new Row()
                {
                    BodyId = sheet.Id,
                    Id = row.Id,
                    Number = row.Number
                };
                db.Row.AddOrUpdate(rowNew);

                sheetNew = new Sheet()
                {
                    Id = sheet.Id,
                    Number = sheet.Number,
                    DocumentId = document.Id,
                    Name = sheet.Name
                };
                bodyNew = new Body()
                {
                    Id = sheet.Id,
                    SheetId = sheet.Id,
                };
                db.Body.AddOrUpdate(bodyNew);
                db.Sheet.AddOrUpdate(sheetNew);


                documentNew = new Document()
                {
                    Id = document.Id,
                    Name = document.Name
                };
                db.Document.AddOrUpdate(documentNew);

                db.SaveChanges();

                db.Dispose();
            }
            catch (Exception exception)
            {

            }


        }
    }
}